<?php
    include "inc/db_connection.php";
    $id = $_GET["id"];
    $itemname = $_POST["albumName"];
    $itemcode = $_POST["code"];
    $description = $_POST["albumImage"];
    $price = $_POST["albumPrice"];
    $reviews = $_POST["albumReviewsNo"];
    $category = $_POST["pr_cat_id"];


    $sql_u = "UPDATE tblHomeProduct SET albumName = '{$itemname}',code = '{$itemcode}', albumImage = '{$description}', albumPrice = '{$price}', albumReviewsNo = '{$reviews}', pr_cat_id = '{$category}' WHERE albumId = '{$id}' ";
    mysqli_query($connection, $sql_u);
    header ("location: admin.php");
?>