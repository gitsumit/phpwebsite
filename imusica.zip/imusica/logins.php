<?php

session_start();
require_once("inc/db_connection.php");

if (isset($_POST["name"]) && isset($_POST["pwd"])) {
    $query = "  
      SELECT * FROM userRegistration  
      WHERE userEmail = '" . $_POST["name"] . "'  
      AND userPassword = '" . $_POST["pwd"] . "'  
      ";
    $result = mysqli_query($connection, $query);
    if (mysqli_num_rows($result) > 0) {
        while($row = $result->fetch_assoc()) {
            $_SESSION['firstName'] = $row['firstName'];
        }

        echo 'Yes';
    } else {
        echo 'No';
    }
}
if (isset($_POST["action"])) {
    unset($_SESSION["firstName"]);
}

?>