<!-- delete -->

<div class="modal fade" id="del<?php echo $row["albumId"];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Delete</h4></center>
            </div>

            <div class="modal-body">
                <?php
                    $sql_d = "SELECT * FROM tblHomeProduct WHERE albumId = '{$row["albumId"]}' ";
                    $del = mysqli_query($connection, $sql_d);
                    $drow = mysqli_fetch_array($del);
                ?>
                <div class ="container-fluid">
                    <h5><center>Album name: <strong><?php echo $drow["albumName"];?></strong></center></h5>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <a href="delete.php?id=<?php echo $drow["albumId"];?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
            </div>
        </div>
    </div>
</div>

<!-- edit -->

<div class="modal fade" id="edit<?php echo $row["albumId"];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Edit</h4></center>
            </div>

            <div class="modal-body">
                <?php
                    $sql_e = "SELECT * FROM tblHomeProduct WHERE albumId = '{$row["albumId"]}' ";
                    //$sql_e = "SELECT * FROM product INNER JOIN category ON product.pr_ct_id = category.ct_id WHERE pr_id = '{$row["pr_id"]}' ";
                    $edit = mysqli_query($connection, $sql_e);
                    $erow = mysqli_fetch_array($edit);
                ?>
                <div class="container-fluid">

                    <form method="POST" action="edit.php?id=<?php echo $erow["albumId"]; ?>">
                        <div class="row">                 
                            <div class="col-lg-2">
                                <label class="control-label" style="position: relative; top: 7px;">Album Name:</label>
                            </div>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="albumName" value="<?php echo $erow["albumName"];?>">
                            </div>
                        </div>
                        
                    
                     <div style="height: 10px;"></div>
                                
                        <div class="row">
                            <div class="col-lg-2">
                                <label class="control-label" style="position: relative; top: 7px;">Image:</label>
                            </div>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="code" value="<?php echo $erow["code"];?>">
                            </div>
                        </div>
                        
                        <div style="height: 10px;"></div>
                                
                        <div class="row">
                            <div class="col-lg-2">
                                <label class="control-label" style="position: relative; top: 7px;">Image:</label>
                            </div>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="albumImage" value="<?php echo $erow["albumImage"];?>">
                            </div>
                        </div>
                            
                        <div style="height: 10px;"></div>
                                
                        <div class="row">
                            <div class="col-lg-2">
                                <label class="control-label" style="position: relative; top: 7px;">Price:</label>
                            </div>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="albumPrice" value="<?php echo $erow["albumPrice"];?>">
                            </div>
                        </div>

                           <div style="height: 10px;"></div>
                                
                        <div class="row">
                            <div class="col-lg-2">
                                <label class="control-label" style="position: relative; top: 7px;">Reviews:</label>
                            </div>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="albumReviewsNo" value="<?php echo $erow["albumReviewsNo"];?>">
                            </div>
                        </div>

                               <div style="height: 10px;"></div>
                                
                        <div class="row">
                            <div class="col-lg-2">
                                <label class="control-label" style="position: relative; top: 7px;">Category Id:</label>
                            </div>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="pr_cat_id" value="<?php echo $erow["pr_cat_id"];?>">
                            </div>
                        </div>
                        
                        
                        <div style="height: 10px;"></div>
                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                            <button type="submit" class="btn btn-warning"><span class="glyphicon glyphicon-check"></span> Save</button>
                        </div>        
                    </form>
                </div>

            </div>
        </div>
    </div>
</div>

<script>

</script>
