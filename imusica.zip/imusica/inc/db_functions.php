<?php
require_once("db_connection.php");

function viewCustomers()
{
    global $connection;
    
    $query = "select * from userRegistration";

    $result = mysqli_query($connection, $query);

    if ($result->num_rows > 0) {

         echo "<table border=1px;>";
         echo "<th>Email</th><th>Name</th>";
        while ($row= $result->fetch_assoc()) {
         echo "<tr>";
         echo "<td>".$row["userEmail"]."</td>";
         echo "<td>".$row["userPassword"]."</td>";	
        }

         echo "</tr>";
         echo "</table>";
    }
    else
    {
        echo "No Data Found";
    }
}

function registerUser($email, $pass)
{
	
	global $connection;
	$sql = "INSERT INTO userRegistration (userTitle, firstName, lastName, gender, dob, address, suburb, city, 
                  postalCode, phoneNumber, userEmail, userPassword, question, ads) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	if($stmt = mysqli_prepare($connection, $sql)){

		mysqli_stmt_bind_param($stmt, "statement", $param_userTitle, $paramFirstName,
            $paramLastName, $paramGender, $paramDob, $paramAddress, $paramSuburb, $paramCity, $paramPostalCode,
            $paramPhoneNumber, $paramEmail, $paramPassword, $paramQuestion, $paramAds);

		// Set parameters
		$paramEmail = $email;
		$paramPassword = password_hash($pass, PASSWORD_DEFAULT); // Creates a password hash

		// Attempt to execute the prepared statement
		if(mysqli_stmt_execute($stmt)){

			// Redirect to login page
			header("location: home.php");

		}else{

			echo "Something went wrong. Try again";
		}
	}

		// Close statement
		mysqli_stmt_close($stmt);

}


function userLogin($email, $pass){
	global $connection;
	$sql = "select * from userRegistration where userEmail= '{$email}' and userPassword = '{$pass}'";
	//echo $sql;
	$result = mysqli_query($connection, $sql);
	if ($result) {
		while($row = mysqli_fetch_assoc($result)) {
			 
			return $row["firstName"];
		}
		
	}else{
		return false;
	}
	
}

function validateEmail($email){
	
$email = "john.doe@example.com";

if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
  echo("$email is a valid email address");
} else {
  echo("$email is not a valid email address");
}
}
?>