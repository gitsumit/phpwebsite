<?php
define('DB_Host', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'imusicadb');

$connection = mysqli_connect(DB_Host, DB_USER, DB_PASSWORD,DB_DATABASE);

?>