<?php
    session_start();
    unset($_SESSION['session_adminLogged']);
	require_once ("inc/db_connection.php");

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
		<meta name="description" content="630-Assignment">
		<meta name="author" content="Ying Zhang">

		<title>Admin Panel</title>

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

		<!-- bootstrap style -->
		<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>
		<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>

	<body onLoad="openLoginModal()">
        
		<div class="container" id="containerForm">

			<div style="height: 50px;"></div>
			<div class="well" style="margin: auto; padding: auto; width: 80%">
				<span style="font-size: 25px; color: blue"><center><strong>iMusica (Admin Panel)</strong></center></span>
				<span class="pull-left"><a href="#addnew" data-toggle="modal" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Add New</a></span>
				
				<div style="height: 50px;"></div>

				<table class="table table-striped table-bordered table-hover">
					<thead>
						<th>Album name</th>
                        <th>Code</th>
						<th>Image</th>
						<th>Price</th>
						<th>Review No</th>
                        <th>Category</th>
						<th>Actions</th>
					</thead>
					<tbody>
						<?php
							global $connection;
//							$sql_q = "SELECT * FROM tblHomeProduct ORDER BY albumId ASC" ;
                            $sql_q = "SELECT * FROM tblHomeProduct INNER JOIN tblProductCategory ON tblHomeProduct.pr_cat_id = tblProductCategory.ct_id";
							$query = mysqli_query($connection, $sql_q);
							while ($row = mysqli_fetch_array($query)) {	
						?>
								<tr>
									<td><?php echo $row["albumName"]; ?></td>
                  		            <td><?php echo $row["code"]; ?></td>
									<td><?php echo $row["albumImage"]; ?></td>
									<td><?php echo $row["albumPrice"]; ?></td>
                                    <td><?php echo $row["albumReviewsNo"]; ?></td>
                                    <td><?php echo $row["ct_name"]; ?></td>



									<td>
										<a href="#edit<?php echo $row["albumId"]; ?>" data-toggle="modal" class="btn btn-warning"><span class="glyphicon glyphicon-edit"></span> Edit</a> ||

										<a href="#del<?php echo $row["albumId"]; ?>" data-toggle="modal" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>

										<?php
											include "inc/uc_modal.php";
										?>
									</td>
								</tr>
						<?php 
							}
						?>
					</tbody>
				</table>
			</div>		
			<?php
				include "inc/add_modal.php";
			?>
		</div>
        
        
        <!--Login Modal -->
<div class="modal fade" id="modalLoginForm" role="dialog" aria-labelledby="myModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div id="alert1" data-dismiss="alert"></div>
            <div class="modal-header text-center">
                <h4 class="modal-title w-100 font-weight-bold">Admin logon</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
            <div class="modal-body mx-3">
                <div class="md-form mb-5">

                    <label data-error="wrong" data-success="right" for="defaultForm-email">Email <i
                                class="fas fa-envelope prefix grey-text"></i></label>
                    <input type="email" id="defaultForm-email" class="form-control validate">
                </div>

                <div class="md-form mb-4">
                    <label data-error="wrong" data-success="right" for="defaultForm-pass">Password <i
                                class="fas fa-lock prefix grey-text"></i></label>
                    <input type="password" id="defaultForm-pass" class="form-control validate">
                </div>

            </div>

            <div class="modal-footer d-flex justify-content-center">
                <button class="btn btn-success" onClick="userLogin()">Login</button>
            </div>


        </div>
    </div>
</div>
<!--end -->
       
<script type="text/javascript">
  
    //user login
    function userLogin()
    {
        var uemail = document.getElementById("defaultForm-email").value;
        var umessage = document.getElementById("defaultForm-pass").value;

     if (uemail.trim() == '') {
            alert('Please enter your email.');
            $('#defaultForm-email').focus();
            return false;
        } else if (umessage.trim() == '') {
            alert('Please type your message.');
            $('#defaultForm-pass').focus();
            return false;
        } 
        else
         {
                    if (userEmail == "sumit" && pass == "sumit") {
    	       $_SESSION["session_adminLogged"] = "YES";
                $('#modalLoginForm').hide();
                        $('#containerForm').show();
            }
            }

 }


   	function openLoginModal(){

   		<?php
   		   		if(isset($_SESSION["session_adminLogged"]))
        {
   		
           }else{
           	?>
            	$('#containerForm').hide();
            	<?php
           }

           ?>
   	}
   	
 $(document).ready(function(){

 	   		<?php
   		   		if(isset($_SESSION["session_adminLogged"]))
        {}else{
        	?>
        	 $('#modalLoginForm').modal({
            show: true
        });
        	 <?php
        }
    ?>
    });

 function userLogin(){
 	

 	var userEmail = document.getElementById("defaultForm-email").value;
    var pass = document.getElementById("defaultForm-pass").value;

    if (userEmail == "sumit" && pass == "sumit") {
    	<?php
    	$_SESSION["session_adminLogged"] = "YES";
    	?>
    	  $('#modalLoginForm').hide();
 	 	$('#containerForm').show();
    }

 }
   </script>

   <style>
.modal-backdrop {
  z-index: -1;
}
</style>
        
        
        
	</body>
</html>



