<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="cafe, queen street, 450 queen st">
  <meta name="author" content="">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  <title>iMusica Online Store</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/imusica_css.css" rel="stylesheet">

        <style>
            .footer {
                       position: fixed;
                       left: 0;
                       bottom: 0;
                       width: 100%;
                       height: 40px;
                       background-color: #72AF54;
                       color: white;
                       text-align: center;
                       font-size: 13px;
                   }
    </style>
</head>

<body onload="placeLabel()">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #72AF54">
   

    <div class="container">
      <a href="home.php" class="navbar-brand"><img src="img/newLogo.png" height="80px" style="margin-top: -20px"></a>
	
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
         <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="home.php"><b>Home</b>
              <span class="sr-only">(current)</span>
            </a>
          </li>

          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <b>iMusica Product</b></a>

          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href=""><b>Categories</b></a>
              <ul class="dropdown-menu sub-menu">
                <li><a class="dropdown-item" href="jazzmusic.php"><b>Jazz</b></a></li>
                <li><a class="dropdown-item" href="popmusic.php"><b>POP</b></a></li>
              </ul>
            </li>
            <li><a class="dropdown-item" href=""><b>Accessories</b></a>
              <ul class="dropdown-menu sub-menu">
                <li><a class="dropdown-item" href="headset.php"><b>Headsets</b></a></li>
                <li><a class="dropdown-item" href="zipster.php"><b>Zipsters</b></a></li>
              </ul>
            </li>
            <li><a class="dropdown-item" href="newitems.php"><b>New items</b></a></li>
            <li><a class="dropdown-item" href="sale.php"><b>Sale</b></a></li>
          </ul>
        </li>
          <li class="nav-item">
            <a class="nav-link" href="aboutus.php"><b>About Us</b></a>
          </li>

    



        </ul>
      </div>
    </div>
  </nav>




<div id="navLabel" style="background: blue; height: 9px"></div>
<div id="alert2" style="" data-dismiss="alert"></div>



  <!-- Page Content -->


  <div style="margin-top:20px" class="container">

    <div class="row">
      
      <div class="col-lg-12">

        <h1 class="my-5" style="margin-left: 10px;">About us</h1>

                <h2>Welcome to <b>iMusica</b></h2>
                <p>
                iMusica may be a comprehensive and in-depth asset for finding out more approximately the collections, performers and melodies you adore.
                </p>

                <p><b>On iMusic you'll find</b></p>


               <div class="features">
                <ul>
                      <li>In-Depth Information about your favorite albums, musicians and songs</li>
                      <li>Reviews of upcoming and classic albums including new releases</li>
                      <li>Ratings and picks of the recommended albums and songs within an artist's discography or tracks on an album</li>
                      <li>Staff picks of the albums our editors are into right now</li>
                      <li>Sound samples and streaming links to listen to the music</li>
                      <li>Personalized recommendations of albums that match your tastes</li>
                </ul>
                </div>
        
        

         </div>
      </div>
      <br/><br/>
      
      <div>
        <h1>Facing problem on site? Please text us.</h1>   
    </div>
      
    <div class="container-fluid bg-light py-3">
        
        <form method="post" id="insert_contact" action="contactus.php">
        <div class="messages"></div>
        <div class="controls">
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="form_name">Name *</label>
                        <input id="username" type="text" name="username" class="form-control" placeholder="Please enter your name *" required="required" data-error="name is required.">
                        <div class="help-block with-errors"></div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="form_email">Email *</label>
                        <input id="useremail" type="email" name="useremail" class="form-control" placeholder="Please enter your email *" required="required" data-error="Valid email is required.">
                        <div class="help-block with-errors"></div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="form_phone">Phone</label>
                        <input id="userphone" type="tel" name="userphone" class="form-control" placeholder="Please enter your phone number">
                        <div class="help-block with-errors"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label for="form_message">Message *</label>
                    <textarea id="usermessage" name="usermessage" class="form-control" placeholder="Message for me *" rows="4" required="required" data-error="send a message."></textarea>
                    <div class="help-block with-errors"></div>
                </div>
            </div>
            <div class="col-md-12">
                 <button type="button" class="btn btn-success" data-toggle="modal"
                                    data-target=".bd-example-modal-lg" style="margin-top: 10px;" onclick="contactus()">Send
                            </button>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <p class="text-muted"><strong>*</strong> These fields are required.</p>
            </div>
        </div>
    </form>
    </div>
      
    </div>
            
    

      
<!--
<div class="container-fluid">
    <div class="row">
        
        
               <div>
                      <H1>Reach us at</H1>
                </div>
        
            <div class="card">
                <div class="card-horizontal">
                    <div class="img-square-wrapper">
                        <a href="#"><img class="card-img-top" src="img/ImgLocation.png" alt=""></a>
                    </div>
                    <div class="card-body" style="">
                        <h4 class="card-title">iMusica Auckland</h4>
                        <h6>450 Queen St, Auckland, 101</h6>
                    </div>
                </div>
            </div>
    </div>
</div>
-->
    
    

<script>
        
        function contactus()
        {
                var uname = document.getElementById("username").value;
                var uemail = document.getElementById("useremail").value;
                var uphone = document.getElementById("userphone").value;
                var umessage = document.getElementById("usermessage").value;

                if (uname.trim() == '') 
                {
                    alert('Please enter your name.');
                    $('#username').focus();
                    return false;
                } 
                else if (uemail.trim() == '') 
                {
                    alert('Please type your email address.');
                    $('#useremail').focus();
                    return false;
                } 
                else if (uphone.trim() == '') {
                    alert('Please type your phone.');
                    $('#userphone').focus();
                    return false;
                }
                else if (umessage.trim() == '') {
                    alert('Please type your message.');
                    $('#usermessage').focus();
                    return false;
                }
                else 
                {
                    $.ajax({
                        url: "contactus.php",
                        method: "POST",
                        data: $('#insert_contact').serialize(),
                        success: function (data) 
                        {    
                            alert("Your message received.We will get back to you sortly.");
                            location.reload();
                        }
                    });
                }
        }

        function placeLabel(){
          var height= document.getElementById("navbarResponsive").offsetHeight;
          document.getElementById("navLabel").style.marginTop=height + 'px';
        }
    
</script>
    
  <!-- Footer -->
  <div class="footer">
    <p>Copyright &copy; iMusica 2019</p>
</div>
    



  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
