<?php
    include "inc/db_connection.php";

    $itemname = $_POST["albumName"];
    $itemcode = $_POST["code"];
    $description = $_POST["albumImage"];
    $price = $_POST["albumPrice"];
    $reviews = $_POST["albumReviewsNo"];
    $productCategory = $_POST["pr_cat_id"];
        
    $sql_a = "INSERT INTO tblHomeProduct (albumName, code, albumImage, albumPrice, albumReviewsNo, pr_cat_id) VALUES ('{$itemname}','{$itemcode}', '{$description}', '{$price}', '{$reviews}', '{$productCategory}')";
    mysqli_query($connection, $sql_a);
    header ("location: admin.php");
?>