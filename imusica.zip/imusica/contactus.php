<?php
    include "inc/db_connection.php";

    $username = $_POST["username"];
    $useremail = $_POST["useremail"];
    $userphone = $_POST["userphone"];
    $usermsg = $_POST["usermessage"];

    $sql_a = "INSERT INTO tblContactus (userEmail, userMessage, userPhone, userName) VALUES ('{$useremail}','{$usermsg}','{$userphone}','{$username}')";
    mysqli_query($connection, $sql_a);
    header ("location: aboutus.php");
?>