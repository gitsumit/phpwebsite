<?php

session_start();
require_once("inc/db_connection.php");


if(!empty($_GET["action"]))
{
    switch($_GET["action"])
    {
        case "remove":
            if(!empty($_SESSION["music_cart_item"]))
            {
                foreach($_SESSION["music_cart_item"] as $k => $v)
                {
                    if($_GET["code"] == $k)
                        unset($_SESSION["music_cart_item"][$k]);
                    
                    if(empty($_SESSION["music_cart_item"]))
                        unset($_SESSION["music_cart_item"]);
                }
            }
            break;
            
        case "empty":
            unset($_SESSION["music_cart_item"]);
            break;

        }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="cafe, queen street, 450 queen st">
  <meta name="author" content="">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  <title>iMusica Online Store</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/imusica_css.css" rel="stylesheet">
    <style>
            .footer {
                       position: fixed;
                       left: 0;
                       bottom: 0;
                       width: 100%;
                       height: 40px;
                       background-color: #72AF54;
                       color: white;
                       text-align: center;
                       font-size: 13px;
                   }
    </style>

    
</head>

<body onload="placeLabel()">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #72AF54">
   

    <div class="container">
      <a href="home.php" class="navbar-brand"><img src="img/newLogo.png" height="80px" style="margin-top: -20px"></a>
	
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
         <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="home.php"><b>Home</b>
              <span class="sr-only">(current)</span>
            </a>
          </li>

          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <b>iMusica Product</b></a>

          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href=""><b>Categories</b></a>
              <ul class="dropdown-menu sub-menu">
                <li><a class="dropdown-item" href="jazzmusic.php"><b>Jazz</b></a></li>
                <li><a class="dropdown-item" href="popmusic.php"><b>POP</b></a></li>
              </ul>
            </li>
            <li><a class="dropdown-item" href=""><b>Accessories</b></a>
              <ul class="dropdown-menu sub-menu">
                <li><a class="dropdown-item" href="headset.php"><b>Headsets</b></a></li>
                <li><a class="dropdown-item" href="zipster.php"><b>Zipsters</b></a></li>
              </ul>
            </li>
            <li><a class="dropdown-item" href="newitems.php"><b>New items</b></a></li>
            <li><a class="dropdown-item" href="sale.php"><b>Sale</b></a></li>
          </ul>
        </li>
          <li class="nav-item">
            <a class="nav-link" href="aboutus.html"><b>About Us</b></a>
          </li>

    



        </ul>
      </div>
    </div>
  </nav>
    
    
    
 <div style="margin-top:60px"></div>

    <div id="shopping-cart">
        <div class="txt-heading">Shopping Cart<a id="btnEmpty" href="cart.php?action=empty">Empty Cart</a></div>
        
        <?php
        if(isset($_SESSION["music_cart_item"]))
        {
            $item_total = 0;
        
        ?>
        
        <table cellpadding="10" cellspacing="1">
        <tbody>
        <tr>
            <th style="text-align:left;"><strong>Name</strong></th>
            <th style="text-align:left;"><strong>Code</strong></th>
            <th style="text-align:right;"><strong>Quantity</strong></th>
            <th style="text-align:right;"><strong>Price</strong></th>
            <th style="text-align:center;"><strong>Action</strong></th>
        </tr> 
            <?php
                foreach($_SESSION["music_cart_item"] as $item)
                {
            ?>
            <tr>
                <td style="text-align:left;border-bottom:#F0F0F0 1px solid;"><strong><?php echo $item["name"];?></strong></td>
                <td style="text-align:left;border-bottom:#F0F0F0 1px solid;"><?php echo $item["code"];?></td>
                <td style="text-align:right;border-bottom:#F0F0F0 1px solid;"><?php echo $item["quantity"];?></td>
                <td style="text-align:right;border-bottom:#F0F0F0 1px solid;"><?php echo "$".$item["price"];?></td>
                <td style="text-align:center;border-bottom:#F0F0F0 1px solid;"><a href="cart.php?action=remove&code=<?php echo $item["code"];?>" class="btnRemoveAction">Remove Item</a></td>
            </tr>
            
            <?php
                    $item_total += ($item["price"]*$item["quantity"]);
            
            }
            ?>
            
            <tr>
                <td colspan="5" align=right><strong>Total:</strong><?php echo "$".$item_total; ?></td>
            </tr>
        </tbody>
        </table>
        
        <?php
        }
        ?>
        
    </div>
    
        
    
    
    
  <!-- Page Content -->

<!--
    <footer class="py-3" style="background-color: #72AF54">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; iMusica 2019</p>
    </div>
     /.container 
  </footer>
-->


  <!-- /.container -->

  <!-- Footer -->
<div class="footer">
    <p>Copyright &copy; iMusica 2019</p>
</div>

    

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
