<?php

session_start();
require_once("inc/db_connection.php");
if (!empty($_POST)) {
    $title = mysqli_real_escape_string($connection, $_POST["title"]);
    $firstname = mysqli_real_escape_string($connection, $_POST["firstname"]);
    $lastname = mysqli_real_escape_string($connection, $_POST["lastname"]);
    $gender = mysqli_real_escape_string($connection, $_POST["gender"]);
    $dob = mysqli_real_escape_string($connection, $_POST["dob"]);
    $mailngemails = mysqli_real_escape_string($connection, $_POST["mailngemails"]);
    $emails = mysqli_real_escape_string($connection, $_POST["emails"]);
    $subrub = mysqli_real_escape_string($connection, $_POST["subrub"]);
    $city = mysqli_real_escape_string($connection, $_POST["city"]);
    $postalcode = mysqli_real_escape_string($connection, $_POST["postalcode"]);
    $phonecontact = mysqli_real_escape_string($connection, $_POST["phonecontact"]);
    $password = mysqli_real_escape_string($connection, $_POST["password"]);
    $question = mysqli_real_escape_string($connection, $_POST["question"]);
    $optradio = mysqli_real_escape_string($connection, $_POST["optradio"]);

    $sql = "SELECT id FROM userRegistration WHERE userEmail = ?";

    if ($stmt = mysqli_prepare($connection, $sql)) {

        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "s", $emails);
        // Set parameters


        // Attempt to execute the prepared statement
        if (mysqli_stmt_execute($stmt)) {

            //store result
            mysqli_stmt_store_result($stmt);

            if (mysqli_stmt_num_rows($stmt) == 1) {


                echo 'No';
            } else {



                $sql = "INSERT INTO userRegistration (userTitle, firstName, lastName, gender, dob, address, suburb, city, 
                  postalCode, phoneNumber, userEmail, userPassword, question, ads) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                if($stmt = mysqli_prepare($connection, $sql)){

                    mysqli_stmt_bind_param($stmt, "sssssssssissss", $title, $firstname,
                        $lastname, $gender, $dob, $mailngemails, $subrub, $city, $postalcode,
                        $phonecontact, $emails, $password, $question, $optradio);

                    // Set parameters
            

                    // Attempt to execute the prepared statement
                    if(mysqli_stmt_execute($stmt)){
                        $_SESSION['firstName'] = $firstname;
                        
                       echo "Yes";

                    }else{

                        echo "No1";
                    }
                }

                // Close statement
                mysqli_stmt_close($stmt);
            }

        } else {

            echo "No1";
        }
    }
}
?>