<?php

session_start();
require_once("inc/db_connection.php");

//admin panel functions
if (!empty($_GET["action"])) {
    switch ($_GET["action"]) {
        case "add":


            if (!empty($_POST["quantity"])) {
                $sql_ = "SELECT * FROM tblHomeProduct WHERE code='" . $_GET["code"] . "'";
                $result = mysqli_query($connection, $sql_);

                while ($row = mysqli_fetch_assoc($result)) {
                    $productByCode = $row;
                }

                $itemArray = array($productByCode["code"] => array('name' => $productByCode["albumName"], 'code' => $productByCode["code"], 'quantity' => $_POST["quantity"], 'price' => $productByCode["albumPrice"]));

                if (!empty($_SESSION["music_cart_item"])) {

                    if (in_array($productByCode["code"], array_keys($_SESSION["music_cart_item"]))) {
                        foreach ($_SESSION["music_cart_item"] as $k => $v) {
                            if ($productByCode["code"] == $k) {
                                if (empty($_SESSION["music_cart_item"][$k]["quantity"])) {
                                    $_SESSION["music_cart_item"][$k]["quantity"] = 0;
                                }
                                $_SESSION["music_cart_item"][$k]["quantity"] += $_POST["quantity"];
                            }
                        }
                    } else {
                        $_SESSION["music_cart_item"] = array_merge($_SESSION["music_cart_item"], $itemArray);
                    }
                } else {
                    $_SESSION["music_cart_item"] = $itemArray;
                }
            }
            break;

        case "remove":
            if (!empty($_SESSION["music_cart_item"])) {
                foreach ($_SESSION["music_cart_item"] as $k => $v) {
                    if ($_GET["code"] == $k)
                        unset($_SESSION["music_cart_item"][$k]);

                    if (empty($_SESSION["music_cart_item"]))
                        unset($_SESSION["music_cart_item"]);
                }
            }
            break;

        case "empty":
            unset($_SESSION["music_cart_item"]);
            break;

    }
}

//end admin panel

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="cafe, queen street, 450 queen st">
    <meta name="author" content="">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
          integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <title>iMusica Online Store</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
          rel="stylesheet">
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/imusica_css.css" rel="stylesheet">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    
    <style>
            .footer {
                       position: fixed;
                       left: 0;
                       bottom: 0;
                       width: 100%;
                       height: 40px;
                       background-color: #72AF54;
                       color: white;
                       text-align: center;
                       font-size: 13px;
                   }
    </style>

</head>

<body onload="placeLabel()">

<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #72AF54">
    <div class="container">
        <a href="home.php" class="navbar-brand"><img src="img/newLogo.png" height="80px" style="margin-top: -20px"></a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive"
                aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="home.php"><b>Home</b>
                        <span class="sr-only">(current)</span>
                    </a>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown"
                       aria-haspopup="true" aria-expanded="false">
                        <b>iMusica Product</b></a>

                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href=""><b>Categories</b></a>
                            <ul class="dropdown-menu sub-menu">
                                <li><a class="dropdown-item" href="jazzmusic.php"><b>Jazz</b></a></li>
                                <li><a class="dropdown-item" href="popmusic.php"><b>POP</b></a></li>
                            </ul>
                        </li>
                        <li><a class="dropdown-item" href=""><b>Accessories</b></a>
                            <ul class="dropdown-menu sub-menu">
                                <li><a class="dropdown-item" href="headset.php"><b>Headsets</b></a></li>
                                <li><a class="dropdown-item" href="zipster.php"><b>Zipsters</b></a></li>
                            </ul>
                        </li>
                        <li><a class="dropdown-item" href="newitems.php"><b>New items</b></a></li>
                        <li><a class="dropdown-item" href="sale.php"><b>Sale</b></a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="aboutus.php"><b>About Us</b></a>
                </li>

           

                <li class="nav-item">
                    <?php
                    if (isset($_SESSION['firstName'])) {
                        ?>

                          <li class="nav-item">
<!--
                    <a class="nav-link" href="customerProfile.php" id="userprofileimg"><img src="img/imgUser.png"
                                                                                            width="30px;"/></a>
-->
                    </li>
                   
                        <a href="" class="nav-link" id="logout12">Welcome <?php echo $_SESSION['firstName']; ?>
                            Logout</a>
                    <?php } else {
                        ?>
                        <a href="" class="nav-link" data-toggle="modal" data-target="#modalLoginForm"
                           id="loginbtn"><b>Login</b></a>

                    <?php }
                    ?>

                </li>

                <li class="nav-item">
                    
                     <a href="cart.php" class="nav-link" id="cart"><b><i class="fas fa-shopping-cart"></i> Cart</b></a>

                </li>

                <!--          <button  type="button" class="btn btn-default" style="color: yellow;" href="cart.html"><i class="fas fa-shopping-cart"></i><span class="badge">7</span></button>-->


                <li class="nav-item">
                    <!--         <a href="customerProfile.html" class="nav-link disabled" data-toggle="modal" data-target="#modalUserprofile" id="userProfilebtn" ><img src="img/imgUser.png" width="30px" /></a> -->

                    <a href="customerProfile.php" class="nav-link" data-toggle="modal" data-target="#modalUserprofile"
                       id="userProfilebtn"></a>
                </li>


            </ul>
        </div>
    </div>
</nav>


<div style="margin-top:40px"></div>


<!--Login Modal -->
<div class="modal fade" id="modalLoginForm" role="dialog" aria-labelledby="myModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div id="alert1" data-dismiss="alert"></div>
            <div class="modal-header text-center">
                <h4 class="modal-title w-100 font-weight-bold">Admin logon</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
            <div class="modal-body mx-3">
                <div class="md-form mb-5">

                    <label data-error="wrong" data-success="right" for="defaultForm-email">Your email <i
                                class="fas fa-envelope prefix grey-text"></i></label>
                    <input type="email" id="defaultForm-email" class="form-control validate">
                </div>

                <div class="md-form mb-4">
                    <label data-error="wrong" data-success="right" for="defaultForm-pass">Your password <i
                                class="fas fa-lock prefix grey-text"></i></label>
                    <input type="password" id="defaultForm-pass" class="form-control validate">
                </div>

            </div>

            <div class="modal-footer d-flex justify-content-center">
                <button class="btn btn-success" onClick="userLogin()">Login</button>
            </div>


        </div>
    </div>
</div>
<!--end -->


<!--registration model start -->

<div class="modal fade" id="modalRegForm" role="dialog" aria-labelledby="myModalLabel"
     aria-hidden="true" style="overflow-y: auto;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div id="alert2" data-dismiss="alert"></div>
            <div class="modal-header text-center">
                <h4 class="modal-title w-100 font-weight-bold">Registration</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>

            <form method="post" id="insert_form">
                <div class="modal-body mx-3" style="overflow-y: auto;">
                    <div class="md-form mb-2">

                        <label data-error="wrong" data-success="right" for="defaultRegForm-title">Title(Mr/Mrs.,Miss
                            etc)*<i
                                    class="fas fa prefix grey-text"></i></label>
                        <input type="text" name="title" id="defaultRegForm-title" class="form-control validate"
                               required>
                    </div>

                    <div class="md-form mb-2">
                        <label data-error="wrong" data-success="right" for="defaultRegForm-fn">First Name *<i
                                    class="fas fa prefix grey-text"></i></label>
                        <input type="text" name="firstname" id="defaultRegForm-fn" class="form-control validate"
                               required>
                    </div>

                    <div class="md-form mb-2">
                        <label data-error="wrong" data-success="right" for="defaultRegForm-ln">Last Name *<i
                                    class="fas fa prefix grey-text"></i></label>
                        <input type="text" name="lastname" id="defaultRegForm-ln" class="form-control validate"
                               required>
                    </div>

                    <div class="md-form mb-2">

                        <label data-error="wrong" data-success="right" for="defaultRegForm-gender">Gender *<i
                                    class="fas fa prefix grey-text"></i></label>
                        <input type="text" name="gender" id="defaultRegForm-gender" class="form-control validate"
                               required>
                    </div>

                    <div class="md-form mb-2">
                        <label data-error="wrong" data-success="right" for="defaultRegForm-dob">DOB *<i
                                    class="fas fa prefix grey-text"></i></label>
                        <input type="text" name="dob" id="defaultRegForm-dob" class="form-control validate" required>
                    </div>

                    <div class="md-form mb-2">
                        <label data-error="wrong" data-success="right" for="defaultRegForm-mail">Mailing Address *<i
                                    class="fas fa prefix grey-text"></i></label>
                        <input type="text" name="mailngemails" id="defaultRegForm-mail" class="form-control validate"
                               required>
                    </div>


                    <div class="md-form mb-2">
                        <label data-error="wrong" data-success="right" for="defaultRegForm-suburb">Suburb *<i
                                    class="fas fa prefix grey-text"></i></label>
                        <input type="text" name="subrub" id="defaultRegForm-suburb" class="form-control validate"
                               required>
                    </div>

                    <div class="md-form mb-2">
                        <label data-error="wrong" data-success="right" for="defaultRegForm-city">City *<i
                                    class="fas fa prefix grey-text"></i></label>
                        <input type="text" name="city" id="defaultRegForm-city" class="form-control validate" required>
                    </div>

                    <div class="md-form mb-2">
                        <label data-error="wrong" data-success="right" for="defaultRegForm-pc">Postal Code *<i
                                    class="fas fa prefix grey-text"></i></label>
                        <input type="text" name="postalcode" id="defaultRegForm-pc" class="form-control validate"
                               required>
                    </div>


                    <div class="md-form mb-2">
                        <label data-error="wrong" data-success="right" for="defaultRegForm-phone">Phone Contact *<i
                                    class="fas fa prefix grey-text"></i></label>
                        <input type="number" name="phonecontact" id="defaultRegForm-phone" class="form-control validate"
                               required>
                    </div>

                    <div class="md-form mb-2">
                        <label data-error="wrong" data-success="right" for="defaultRegForm-phone">Email *<i
                                    class="fas fa prefix grey-text"></i></label>
                        <input type="email" name="emails" id="defaultRegForm-email" class="form-control validate"
                               required>
                    </div>

                    <div class="md-form mb-2">
                        <label data-error="wrong" data-success="right" for="defaultRegForm-password">Password *<i
                                    class="fas fa prefix grey-text"></i></label>
                        <input type="password" name="password" id="defaultRegForm-password"
                               class="form-control validate" required>
                    </div>

                    <div class="md-form mb-2">
                        <label data-error="wrong" data-success="right" for="defaultRegForm-que">How did you hear about
                            us? *<i
                                    class="fas fa prefix grey-text"></i></label>

                        <!--                    <div class="dropdown">-->
                        <select class="dropdown" name="question" aria-labelledby="dropdownMenuButton"
                                aria-haspopup="true"
                                aria-expanded="false" id="dropdownMenuButton">
                            <option value="">Select</option>
                            <option value="Website/Social media">Website/Social media</option>
                            <option value="Reference">Reference</option>
                            <option value="Newspaper/Article">Newspaper/Article</option>
                        </select>
          
                    </div>

                    <div class="md-form mb-2">
                        <label data-error="wrong" data-success="right" for="defaultRegForm-newsletter">Are you
                            interested in
                            receiving specials from us in future? *<i class="fas fa prefix grey-text"></i></label>
                        <label class="radio-inline"><input type="radio" name="optradio" value="Yes" checked>Yes</label>
                        <label class="radio-inline"><input type="radio" name="optradio" value="No">No</label>
                    </div>


                </div>
            </form>
            <div class="modal-footer d-flex justify-content-center">
                <button class="btn btn-success" data-target="modal" onClick="userRegistration()">Sign up</button>
            </div>

        </div>
    </div>
</div>

<!--registration end -->

<div id="alert2" style="" data-dismiss="alert"></div>

<script>


    function userRegistration() {

        var title = document.getElementById("defaultRegForm-title").value;
        var firstName = document.getElementById("defaultRegForm-fn").value;
        var lastName = document.getElementById("defaultRegForm-ln").value;
        var gender = document.getElementById("defaultRegForm-gender").value;
        var dob = document.getElementById("defaultRegForm-dob").value;
        var mailingAddress = document.getElementById("defaultRegForm-mail").value;
        var suburb = document.getElementById("defaultRegForm-suburb").value;
        var city = document.getElementById("defaultRegForm-city").value;
        var postalCode = document.getElementById("defaultRegForm-pc").value;
        var phoneNumber = document.getElementById("defaultRegForm-phone").value;
        var email = document.getElementById("defaultRegForm-email").value;
        var password = document.getElementById("defaultRegForm-password").value;
        var question = $('#dropdownMenuButton').val();  //static stored

        if (title.trim() == '') {
            alert('Please enter your Title.');
            $('#defaultRegForm-title').focus();
            return false;
        } else if (firstName.trim() == '') {
            alert('Please enter your First name.');
            $('#defaultRegForm-fn').focus();
            return false;
        } else if (lastName.trim() == '') {
            alert('Please enter your Last name.');
            $('#defaultRegForm-ln').focus();
            return false;
        } else if (gender.trim() == '') {
            alert('Please enter your Gender.');
            $('#defaultRegForm-gender').focus();
            return false;
        } else if (dob.trim() == '') {
            alert('Please enter your DOB.');
            $('#defaultRegForm-dob').focus();
            return false;
        } else if (mailingAddress.trim() == '') {
            alert('Please enter your MailingAddress.');
            $('#defaultRegForm-mail').focus();
            return false;
        } else if (suburb.trim() == '') {
            alert('Please enter your Subrub.');
            $('#defaultRegForm-suburb').focus();
            return false;
        } else if (city.trim() == '') {
            alert('Please enter your City.');
            $('#defaultRegForm-city').focus();
            return false;
        } else if (postalCode.trim() == '') {
            alert('Please enter your Postal Code.');
            $('#defaultRegForm-pc').focus();
            return false;
        } else if (phoneNumber.trim() == '') {
            alert('Please enter your Phone number.');
            $('#defaultRegForm-phone').focus();
            return false;
        } else if (email.trim() == '') {
            alert('Please enter your Email.');
            $('#defaultRegForm-email').focus();
            return false;
        }
        else if (password.trim() == '') {
            alert('Please enter your Password.');
            $('#defaultRegForm-password').focus();
            return false;
        } else if (question.trim() == '') {
            alert('Please Select your Question.');
            return false;
        } else {
            $.ajax({
                url: "signup.php",
                method: "POST",
                data: $('#insert_form').serialize(),
                success: function (data) {
                    //alert(data);
                    if (data == 'No') {
                        document.getElementById("alert2").className = "alert alert-danger alert-dismissible fade show";
                        document.getElementById("alert2").innerHTML = "This username is already taken.";
                    } else if (data == 'No1') {
                        document.getElementById("alert2").className = "alert alert-danger alert-dismissible fade show";
                        document.getElementById("alert2").innerHTML = "Oops! Something went wrong. Please try again later.";
                    }else if (data == "Yes"){
                        location.reload();
                    }

                }
            });
        }
    }
    
    function contactus()
    {
        var uemail = document.getElementById("useremail").value;
        var umessage = document.getElementById("usermessage").value;
        
        if (uemail.trim() == '') {
            alert('Please enter your email.');
            $('#useremail').focus();
            return false;
        } else if (umessage.trim() == '') {
            alert('Please type your message.');
            $('#usermessage').focus();
            return false;
        } else {
            $.ajax({
                url: "contactus.php",
                method: "POST",
                data: $('#insert_contact').serialize(),
                success: function (data) {
                    
                    alert("Your message received.We will get back to you sortly.");
                
                        location.reload();
                }
            });
        }
    }

   

    function placeLabel() {
        var height = document.getElementById("navbarResponsive").offsetHeight;
        document.getElementById("navLabel").style.marginTop = height + 'px';
        document.getElementById("userprofileimg").style.display = "none";
    }
    



</script>
            

<!-- Page Content -->


<div style="margin-top:20px" class="container">

    <div class="row">

        <!-- /.col-lg-3 -->

        <div class="col-lg-9">

            <div id="carouselExampleIndicators" class="carousel slide my-4" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner" role="listbox">
                    <div class="carousel-item active">
                        <img class="d-block img-fluid" src="img/imgcarousel1.jpg" alt="First slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block img-fluid" src="img/imgcarousel3.jpg" alt="Second slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block img-fluid" src="img/imgcarousel2.jpg" alt="Third slide">
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
        <!-- /.row -->

        <div class="col-lg-3">

            <h2 class="my-3">Reach us at</h2>
            <div class="col-lg-3 col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-title"><h6><b>Location</b></h6></div>
                <a href="#"><img class="card-img-top" src="img/ImgLocation.png" alt=""></a>
                <div class="card-body">
                    <h2>iMusica Auckland</h2>
                    <h6>450 Queen St, Auckland, 101</h6>
                </div>
            </div>
        </div>

        </div>
    </div>
    <!-- /.col-lg-9 -->

    <br>
    <div class="row" style="margin-left: 1px;"><b>Recent Products</b></div>
    <br>


    <div class="row">

        <?php

        global $connection;

        $sql = "SELECT * FROM tblHomeProduct where pr_cat_id = 1";
        $result = mysqli_query($connection, $sql);

        while ($row = mysqli_fetch_assoc($result)) {
            $ArrayHomeProduct[] = $row;
        }

        if (!empty($ArrayHomeProduct)) {
            foreach ($ArrayHomeProduct as $key => $value) {
                ?>

                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card h-100">

                        <form method="post"
                              action="home.php?action=add&code=<?php echo $ArrayHomeProduct[$key]["code"]; ?>">

                            <a href="#"><img class="card-img-top"
                                             src="<?php echo $ArrayHomeProduct[$key]["albumImage"]; ?>" alt=""></a>
                            <div class="card-body">
                                <h4 class="card-title">
                                    <a href="#"><?php echo $ArrayHomeProduct[$key]["albumName"]; ?></a></h4>
                                <h5>$<?php echo $ArrayHomeProduct[$key]["albumPrice"]; ?>.00</h5>
                            </div>

                            <div><input type="text" name="quantity" value="1" size="2"/>
                                
                                <button type="submit" class="btn btn-primary active" onClick="addtocart()"
                                        data-toggle="modal" data-target="#exampleModal"><b>Add to Cart</b>
                                </button>
                                
                            </div>


                            <div class="card-footer">


                                <!-- Add icon library -->
                                <link rel="stylesheet"
                                      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star"></span>


                                <span class="text"><b><?php echo $ArrayHomeProduct[$key]["albumReviewsNo"]; ?></b></span>
                                <!-- <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small> -->
                            </div>
                        </form>
                    </div>
                </div>


                <?php
            }
        }
        ?>
    </div>

</div>
<!-- /.container -->




<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
    


<script>

    function addtocart() {
        
          alert("Product added to the Cart.")

    }
</script>
    
<div class="footer">
    <p>Copyright &copy; iMusica 2019</p>
</div>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<script>
    $(document).ready(function () {

        $('#logout12').click(function () {

            var action = "logout";
            $.ajax({
                url: "logins.php",
                method: "POST",
                data: {action: action},
                success: function () {
                    location.reload();
                }
            });
        });
    });
    
     function userLogin() {
        
        var userEmail = document.getElementById("defaultForm-email").value;
        var userPassword = document.getElementById("defaultForm-pass").value;
        if (userEmail != '' && userPassword != '') {
            $.ajax({
                url: 'logins.php',
                type: "POST",
                data: {name: userEmail, pwd: userPassword},
                cache: false,
                success: function (data) {
                    //alert(data);
                    if (data == 'No') {
                        document.getElementById("alert1").className = "alert alert-danger alert-dismissible fade show";
                        document.getElementById("alert1").innerHTML = "Wrong Data";

                    }
                    else {
                        $("#modalLoginForm").modal('hide');

                       

                        //document.getElementById("userprofileimg").style.display = "block";
                        document.getElementById("loginbtn").style.display = "none";
                        location.reload();
                    }

                }
            });
            event.preventDefault();
        } else {
            document.getElementById("alert1").className = "alert alert-danger alert-dismissible fade show";
            document.getElementById("alert1").innerHTML = "Both Fields are required";

        }
         
    }
</script>
</body>

</html>
