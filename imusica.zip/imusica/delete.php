<?php
    include "inc/db_connection.php";
    $id = $_GET["id"];
    $sql_d = "DELETE FROM tblHomeProduct WHERE albumId = '{$id}' ";
    mysqli_query($connection, $sql_d);
    header ("location: admin.php");
?>