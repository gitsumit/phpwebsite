<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="cafe, queen street, 450 queen st">
  <meta name="author" content="">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  <title>iMusica Online Store</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/imusica_css.css" rel="stylesheet">

    
    <style>
            .footer {
                       position: fixed;
                       left: 0;
                       bottom: 0;
                       width: 100%;
                       height: 40px;
                       background-color: #72AF54;
                       color: white;
                       text-align: center;
                       font-size: 13px;
                   }
    </style>
    
    
</head>

<body onload="placeLabel()">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #72AF54">
    <div class="container">
      <a href="home.php" class="navbar-brand"><img src="img/newLogo.png" height="80px" style="margin-top: -20px"></a>
  
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
         <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="home.php"><b>Home</b>
              <span class="sr-only">(current)</span>
            </a>
          </li>

          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <b>iMusica Product</b></a>

          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href=""><b>Categories</b></a>
              <ul class="dropdown-menu sub-menu">
                <li><a class="dropdown-item" href="jazzmusic.php"><b>Jazz</b></a></li>
                <li><a class="dropdown-item" href="popmusic.php"><b>POP</b></a></li>
              </ul>
            </li>
            <li><a class="dropdown-item" href=""><b>Accessories</b></a>
              <ul class="dropdown-menu sub-menu">
                <li><a class="dropdown-item" href="headset.php"><b>Headsets</b></a></li>
                <li><a class="dropdown-item" href="zipster.php"><b>Zipsters</b></a></li>
              </ul>
            </li>
            <li><a class="dropdown-item" href="newitems.php"><b>New items</b></a></li>
            <li><a class="dropdown-item" href="sale.php"><b>Sale</b></a></li>
          </ul>
        </li>
          <li class="nav-item">
            <a class="nav-link" href="aboutus.php"><b>About Us</b></a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="customerProfile.php" id="userprofileimg"><img src="img/imgUser.png" width="30px;" /></a>
          </li>


           <li class="nav-item">
    <!--         <a href="customerProfile.html" class="nav-link disabled" data-toggle="modal" data-target="#modalUserprofile" id="userProfilebtn" ><img src="img/imgUser.png" width="30px" /></a> -->

             <a href="customerProfile.php" class="nav-link" data-toggle="modal" data-target="#modalUserprofile" id="userProfilebtn"></a> 
           </li>




        </ul>
      </div>
    </div>
  </nav>





<div id="navLabel" style="background: blue; height: 9px"></div>
<div id="alert2" style="" data-dismiss="alert"></div>

  
  <!-- Page Content -->


  <div style="margin-top:20px" class="container">

    <div class="row">

   
      
      <div class="col-lg-12">

        <h2 class="my-5" style="margin-left: 10px;">Update Profile</h2>
              <div class="container">
               
       <div class="container">
             <form class="form-container"> 

                    <div class="form-group">
                        <label for="inputName">Name</label>
                        <input type="name" class="form-control" id="inputName" placeholder="Enter profile username" required />
                    </div>
                    <div class="form-group">
                        <label for="inputEmail">Email</label>
                        <input type="email" class="form-control" id="inputEmail" placeholder="Enter email address" required />
                    </div>
                    <div class="form-group">
                        <label for="inputPassword">Change Password</label>
                        <input type="password" class="form-control" id="inputPassword" placeholder="New password" required />
                    </div>
                     <div class="form-group">
                        <label for="inputCPassword">Current Password</label>
                        <input type="password" class="form-control" id="inputCPassword" placeholder="Enter current password to update profile" required />
                    </div>
                   <button type="submit" class="btn btn-success" data-toggle="modal" onclick="userUpdate()" data-target="#profileupdated">Update Profile</button>

                   <button type="button" class="btn btn-danger btn" data-toggle="modal" data-target="#myModal">Delete Profile</button>


              </form>
            </div>
          </div>
              </div>
      </div>

               
        </div>

      </div>

    </div>
    <!-- /.row -->
  </div>


  <!-- Modal -->
<div id="myModal" class="modal fade" role="dialog" data-target="emailidconfirm">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
     
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Delete Account</h4>
          </div>
          <div class="modal-body">
            <label for="inputPassword">Password</label>
            <input type="password" class="form-control" id="inputPassword" placeholder="enter your password to delete imusica account" required /></br>

            <button type="button" class="btn btn-danger btn" data-toggle="modal" data-target="#afterDelete" onclick="afterDelete()">Confirm</button>

          </div>
      </div>    
    </div>

  </div>
</div>

 <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="afterDelete" onclick="afterdelete()" data-target="#afterDelete">
                       <div class="modal-dialog modal-sm">

                        <div class="modal-content">
                            Account deleted!
                            We wish to see you again.     
                        </div>
                    </div></div>

 <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="profileupdated" onclick="profileupdated()">

                       <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                            Success! Your profile is updated.   
                        </div>
                    </div></div>

  <script>
    
    function redirectPage()
    {
      // $("#profileupdated").modal('hide');


    }

    function profileupdated()
    {
      // $("#myModal").modal('hide');
     

    }

    function afterdelete()
    {
      $("#emailidconfirm").modal('hide');
]
      location.replace("home.php");

    }

  </script>
  <!-- /.container -->

    
<div class="footer">
    <p>Copyright &copy; iMusica 2019</p>
</div>


  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
