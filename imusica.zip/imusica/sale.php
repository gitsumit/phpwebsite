<?php

session_start();
require_once("inc/db_connection.php");
include 'inc/db_functions.php';


if(!empty($_GET["action"]))
{
    switch($_GET["action"])
    {
        case "add":
            
            
            if(!empty($_POST["quantity"]))
            {
                $sql_="SELECT * FROM tblHomeProduct WHERE code='".$_GET["code"]."'";
                $result = mysqli_query($connection,$sql_);
                
                while($row=mysqli_fetch_assoc($result))
                {
                    $productByCode = $row;
                }
       
                $itemArray = array($productByCode["code"]=>array('name'=>$productByCode["albumName"], 'code'=>$productByCode["code"], 'quantity'=>$_POST["quantity"], 'price'=>$productByCode["albumPrice"]));
                
                if(!empty($_SESSION["music_cart_item"]))
                {
                    
                    if(in_array($productByCode["code"],array_keys($_SESSION["music_cart_item"])))
                    {
                        foreach($_SESSION["music_cart_item"] as $k => $v)
                        {
                            if($productByCode["code"] == $k)
                            {
                                if(empty($_SESSION["music_cart_item"][$k]["quantity"]))
                                {
                                    $_SESSION["music_cart_item"][$k]["quantity"] = 0;
                                }
                                $_SESSION["music_cart_item"][$k]["quantity"]+=$_POST["quantity"];
                            }
                        }
                    }
                    else
                    {
                        $_SESSION["music_cart_item"]=array_merge($_SESSION["music_cart_item"],$itemArray);
                    }
                }
                else
                {
                        $_SESSION["music_cart_item"] = $itemArray;
                }
            }
            break;  
            
        case "remove":
            if(!empty($_SESSION["music_cart_item"]))
            {
                foreach($_SESSION["music_cart_item"] as $k => $v)
                {
                    if($_GET["code"] == $k)
                        unset($_SESSION["music_cart_item"][$k]);
                    
                    if(empty($_SESSION["music_cart_item"]))
                        unset($_SESSION["music_cart_item"]);
                }
            }
            break;
            
        case "empty":
            unset($_SESSION["music_cart_item"]);
            break;

        }
}
?>





<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="cafe, queen street, 450 queen st">
  <meta name="author" content="">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  <title>iMusica Online Store</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/imusica_css.css" rel="stylesheet">

        <style>
            .footer {
                       position: fixed;
                       left: 0;
                       bottom: 0;
                       width: 100%;
                       height: 40px;
                       background-color: #72AF54;
                       color: white;
                       text-align: center;
                       font-size: 13px;
                   }
    </style>
    
</head>

<body onload="placeLabel()">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #72AF54">
    <div class="container">
      <a href="home.php" class="navbar-brand"><img src="img/newLogo.png" height="80px" style="margin-top: -20px"></a>
	
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="home.php"><b>Home</b>
              <span class="sr-only">(current)</span>
            </a>
          </li>

          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><b>
            iMusica Product</b></a>

      <ul class="dropdown-menu">
            <li><a class="dropdown-item" href=""><b>Categories</b></a>
              <ul class="dropdown-menu sub-menu">
                <li><a class="dropdown-item" href="jazzmusic.php"><b>Jazz</b></a></li>
                <li><a class="dropdown-item" href="popmusic.php"><b>POP</b></a></li>
              </ul>
            </li>
            <li><a class="dropdown-item" href=""><b>Accessories</b></a>
              <ul class="dropdown-menu sub-menu">
                <li><a class="dropdown-item" href="headset.php"><b>Headsets</b></a></li>
                <li><a class="dropdown-item" href="zipster.php"><b>Zipsters</b></a></li>
              </ul>
            </li>
            <li><a class="dropdown-item" href="newitems.php"><b>New items</b></a></li>
            <li><a class="dropdown-item" href="sale.php"><b>Sale</b></a></li>
          </ul>
        </li>
          <li class="nav-item">
            <a class="nav-link" href="aboutus.php"><b>About Us</b></a>
          </li>


        </ul>
      </div>
    </div>
  </nav>




<div id="navLabel" style="background: blue; height: 9px"></div>
<div id="alert2" style="" data-dismiss="alert"></div>

<script> 

funcion loadJazz()
{
    alert("loadjazz");
}

function userRegistration()

{
    var userEmail = document.getElementById("reg-email").value;
    var userPassword = document.getElementById("reg-pass").value;
    var userConfirmPassword = document.getElementById("reg-cpass").value;

    if(userEmail!= "admin" && userPassword !="123")
    {
        document.getElementById("alert1").className="alert alert-danger alert-dismissible fade show";
        document.getElementById("alert1").innerHTML="wrong Email / Password";
    }
    else{

        document.getElementById("alert2").style="margin-top: 60px";
        document.getElementById("alert2").className="alert alert-success alert-dismissible fade show";
        document.getElementById("alert2").innerHTML="Welcome Admin ! ";
        $("#modalRegistrationForm").modal('hide');
        var loginLink = document.getElementById("regbtn");
        loginLink.style.display="none";
    }


function userLogin()
{

    $("modalRegistrationForm").modal("hide");

}

function placeLabel(){
  var height= document.getElementById("navbarResponsive").offsetHeight;
  document.getElementById("navLabel").style.marginTop=height + 'px';
}


funcion alertSubmit()
{
  var userEmail = document.getElementById("contactusEmail").value;
  var userMessage = document.getElementById("contactusMessage").value;

if(userEmail!= "" && userMessage != ""){
 document.getElementById("alert1").className="alert alert-danger alert-dismissible fade show";
 document.getElementById("alert1").innerHTML="wrong Email / Password";
} 

}





</script>
  
  <!-- Page Content -->


  <div style="margin-top:100px;" class="container">

      <div class="row" style="margin-top: 5px;" >
            <div class="col-lg-12"> 
                <div class="card h-100" style="width: 1120px;">
                   <a href="#"><img class="card-img-top" src="img/ImgHeader.jpeg" alt=""></a>
                </div>
              </div>

      </div>


     <div class="row" style="margin-top: 40px;"></div>
    
      <div class="row" style="margin-left: 1px;" ><b>Product in sale</b></div><br>  
      
    <!--      cardviews start-->
      
      <div class="row">
        
                <?php
    
			    global $connection;

			    $sql = "SELECT * FROM tblHomeProduct where pr_cat_id=5";
			    $result = mysqli_query($connection,$sql);

			        while($row=mysqli_fetch_assoc($result)) {
			            $ArrayHomeProduct[]=$row;
			          }

              	if (!empty($ArrayHomeProduct))
        			{
            			foreach($ArrayHomeProduct as $key=>$value)
            			{
                ?>
          
         <div class="col-lg-3 col-md-6 mb-4">
            <div class="card h-100">
                
              <form method="post" action="sale.php?action=add&code=<?php echo $ArrayHomeProduct[$key]["code"]; ?>">
                  
              <a href="#"><img class="card-img-top" src="<?php echo $ArrayHomeProduct[$key]["albumImage"];?>" alt=""></a>
              <div class="card-body">
                <h4 class="card-title">
                  <a href="#"><?php echo $ArrayHomeProduct[$key]["albumName"]; ?></a></h4>
                                <h5>$<?php echo $ArrayHomeProduct[$key]["albumPrice"]; ?>.00</h5>
              </div>

            <div><input type="text" name="quantity" value="1" size="2" /><button type="submit" class="btn btn-primary active" onclick="addtocart()" data-toggle="modal" data-target="#productAddedCart"><b>Add to Cart</b></button></div>
            

                </form>
             </div>
             </div>


            <?php
                }
                }
            ?>
          
      </div>
<!--      cardview end-->





  <div style="margin-top:20px;" class="container">

      <div class="col-lg-12">


       <div class="row" style="margin-top: 5px;">
         <div class="col-lg-3 col-md-6 mb-4">
              <a href="#"><img class="card-img-top" src="img/mpimg1.jpg" alt="" id="catImg1"></a>
          </div>

          <div class="col-lg-3 col-md-6 mb-4">
              <a href="#"><img class="card-img-top" src="img/mpimg2.jpg" alt="" id="catImg2"></a>
          </div>
          <div class="col-lg-3 col-md-6 mb-4">
              <a href="#"><img class="card-img-top" src="img/mpimg3.jpg" alt="" id="catImg3"></a>
          </div>
          <div class="col-lg-3 col-md-6 mb-4">
              <a href="#"><img class="card-img-top" src="img/mpimg4.jpg" alt="" id="catImg4"></a>
          </div>


          <div class="col-lg-3 col-md-6 mb-4">
              <a href="#"><img class="card-img-top" src="img/mpimg5.jpg" alt="" id="catImg5"></a>
          </div>

          <div class="col-lg-3 col-md-6 mb-4">
              <a href="#"><img class="card-img-top" src="img/mpimg6.jpg" alt="" id="catImg6"></a>
          </div>

          <div class="col-lg-3 col-md-6 mb-4">
              <a href="#"><img class="card-img-top" src="img/mpimg1.jpg" alt="" id="catImg7"></a>
          </div>

          <div class="col-lg-3 col-md-6 mb-4">
              <a href="#"><img class="card-img-top" src="img/mpimg2.jpg" alt="" id="catImg8"></a>
          </div>


        </div></div></div></div>


<script>
   function addtocart()
    {
        alert("Product added to the Cart."); 
    }
</script>


<div class="footer">
    <p>Copyright &copy; iMusica 2019</p>
</div>


  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
